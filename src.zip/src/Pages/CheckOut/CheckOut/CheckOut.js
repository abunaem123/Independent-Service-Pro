import React from 'react';

const CheckOut = () => {
    return (
        <div className='container'>
            <h2>Please Pay for your booking</h2>
        </div>
    );
};

export default CheckOut;