import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <footer>
            <p><small className='footer-text'>Copyright By Abu Naem</small></p>
        </footer>
    );
};

export default Footer;